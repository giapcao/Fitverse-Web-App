namespace WebApi.Constants;

public static class CorsPolicyNames
{
    public const string VNPay = "VNPay";
}
