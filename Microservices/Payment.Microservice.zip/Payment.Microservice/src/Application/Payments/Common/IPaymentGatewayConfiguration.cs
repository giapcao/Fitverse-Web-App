namespace Application.Payments.Common;

public interface IPaymentGatewayConfiguration
{
}
